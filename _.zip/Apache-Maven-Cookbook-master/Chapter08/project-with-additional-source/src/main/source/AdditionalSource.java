package com.packt.cookbook;
public class AdditionalSource {
    public int simpleMethod() {
        return 1;
    }
}
