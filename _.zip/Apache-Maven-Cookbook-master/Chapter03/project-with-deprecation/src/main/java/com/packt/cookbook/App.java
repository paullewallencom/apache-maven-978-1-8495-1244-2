package com.packt.cookbook;
import java.util.Date;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Date newYear = new Date(2014, 1, 1);
        System.out.println( "Hello World!" );
    }
}
